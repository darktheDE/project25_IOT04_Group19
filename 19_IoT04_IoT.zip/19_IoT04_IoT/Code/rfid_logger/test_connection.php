<?php
// Chỉ đơn giản là báo hiệu đã truy cập được file này
header("Content-Type: text/plain"); // Đặt kiểu nội dung là text
echo "CONNECTION_OK"; // In ra thông báo này
exit(); // Kết thúc ngay lập tức
?>